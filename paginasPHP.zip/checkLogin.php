<?php
/*
    if( isset($_SESSION['id'])){
        header('location:indexnum2.php');
    }
*/    
?>