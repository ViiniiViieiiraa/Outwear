<?php
/*
if($_SESSION['profile']!='Admin'){
    header('location:indexnum2.php');
}
*/
?>