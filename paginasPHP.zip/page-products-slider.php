<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>mPurpose - Multipurpose Feature Rich Bootstrap Template</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/icomoon-social.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,600,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/leaflet.css" />
		<!--[if lte IE 8]>
		    <link rel="stylesheet" href="css/leaflet.ie.css" />
		<![endif]-->
		<link rel="stylesheet" href="css/main.css">

        <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
		<link rel="icon" href="BancoDeImagens/Logos/LogoColorida/(2) 500LogoColorida.png">
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        

        <!-- Navigation & Logo-->
        <div class="mainmenu-wrapper">
	        <div class="container">
	        	<div class="menuextras">
					<div class="extras">
						<ul>
							<li class="shopping-cart-items"><i class="glyphicon glyphicon-shopping-cart icon-white"></i> <a href="page-shopping-cart.php"><b>3 items</b></a></li>
							<li>
								<div class="dropdown choose-country">
									<a class="#" data-toggle="dropdown" href="#"><img src="img/flags/br.png" alt="Brasil"> BR</a>
								</div>
							</li>
			        		<li><a href="page-login.php">Login</a></li>
			        	</ul>
					</div>
		        </div>
		        <nav id="mainmenu" class="mainmenu">
					<ul>
						<li class="logo-wrapper"><a href="index.php"><img src="img/logoout.png" alt="Multipurpose Twitter Bootstrap Template"></a></li>
						<li class="active">
							<a href="index.php">Pagina Inicial</a>
						</li>
						<li>
							<a href="page-portfolio-3-columns-1.php">Roupas</a>
						</li>
						

<!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --><!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- -->

						<li class="has-submenu">
							<a href="#">Navegar</a>
							<div class="mainmenu-submenu">
								<div class="mainmenu-submenu-inner"> 
									<div>
										<h4>Sobre nós</h4>
										<ul>
											<li><a href="page-team.php">Nosso time</a></li> <!-- --> <!-- -->
											<li><a href="page-terms-privacy.php">Termos e Privacidade</a></li> <!-- --> <!-- -->
											<li><a href="page-faq.php">Perguntas Frequentes</a></li> <!-- --> <!-- -->
											<li><a href="page-testimonials-clients.php">Avaliações de clientes</a></li> <!-- --> <!-- -->
										</ul>
									</div>
									<div>
										<h4>Our Work (Portfolio)</h4>
										<ul>
										<!--	<li><a href="page-portfolio-2-columns-1.php">Listagem de produtos  ( 1 )</a></li> -->
											<li><a href="page-portfolio-3-columns-1.php">Listagem de produtos ( 2 )</a></li><!-- --> <!-- -->
										<!--	<li><a href="page-portfolio-item.php">Descricao Produto</a></li>  -->
											<li><a href="page-password-reset.php">Resetar senha</a></li> <!-- --> <!-- -->
										</ul>
									</div>
									<div>
										<h4>eShop</h4>
										<ul>
											<li><a href="page-products-3-columns.php">Products listing (3 Columns)</a></li> <!-- --> <!-- -->
											<li><a href="page-products-slider.php">Products Slider</a></li> <!-- --> <!-- -->
											<li><a href="page-product-details.php">Product Details</a></li><!-- --> <!-- -->
											<li><a href="page-shopping-cart.php">Shopping Cart</a></li><!-- --> <!-- -->
										</ul>
										<h4>Blog</h4>
										<ul>
											<li><a href="page-blog-posts.php">Nossos Blogs</a></li><!-- --> <!-- -->
											<li><a href="page-blog-post-right-sidebar.php">Blog Single Post (Right Sidebar)</a></li><!-- --> <!-- -->
										</ul>
									</div>
								</div><!-- /mainmenu-submenu-inner -->
							</div><!-- /mainmenu-submenu -->
						</li>

<!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --><!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- --> <!-- -->

						<li>
							<a href="page-team.php">Nossa Equipe</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
		<!-- / Navegation e logo fim -->

        <!-- Page Title -->
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>Products Slider</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="products-slider">
							<!-- Products Slider Item -->
							<div class="shop-item">
								<!-- Product Image -->
								<div class="image">
									<a href="page-product-details.php"><img src="img/product1.jpg" alt="Item Name"></a>
								</div>
								<!-- Product Title -->
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<!-- Product Price -->
								<div class="price">
									$999.99
								</div>
								<!-- Buy Button -->
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<!-- End Products Slider Item -->
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product2.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product3.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product4.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product5.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product6.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product7.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
							<div class="shop-item">
								<div class="image">
									<a href="page-product-details.php"><img src="img/product8.jpg" alt="Item Name"></a>
								</div>
								<div class="title">
									<h3><a href="page-product-details.php">Lorem ipsum dolor</a></h3>
								</div>
								<div class="price">
									$999.99
								</div>
								<div class="actions">
									<a href="page-product-details.php" class="btn btn-small"><i class="icon-shopping-cart icon-white"></i> Buy</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	    </div>

	    <!-- Footer -->
	    <div class="footer">
	    	<div class="container">
		    	<div class="row">
		    		<div class="col-footer col-md-2 col-xs-6">
		    			<h3>Multiplataformas!</h3>
		    			<div class="portfolio-item">
							<div class="portfolio-image">
								<a><img src="img/homepage-slider/slide1.png" alt="Project Name"></a>
							</div>
						</div>
		    		</div>
		    		<div class="col-footer col-md-3 col-xs-6">
		    			<h3>Navegar</h3>
		    			<ul class="no-list-style footer-navigate-section">
		    				<li><a href="index.php">Inicio</a></li>
		    				<li><a href="page-portfolio-3-columns-1.php">Roupas</a></li>
		    				<li><a href="page-team.php">Equipe</a></li>
		    				<li><a href="page-testimonials-clients.php">Avaliações</a></li>
		    				<li><a href="page-blog-posts.php">Blog</a></li>
		    				<li><a href="page-faq.php">FAQ</a></li>
		    			</ul>
		    		</div>
		    		
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3>Contate-nos</h3>
		    			<p class="contact-us-details">
	        				<b>Endereço:</b> R. Fashion, 456 – Hortolândia, Brasil<br/>
	        				<b>Telefone:</b> +55 (19) 988029822<br/>
	        				<b>Email:</b> <a href="mailto:suporteoutwear@gmail.com">suporteoutwear@gmail.com</a>
	        			</p>
		    		</div>
		    		<div class="col-footer col-md-2 col-xs-6">
		    			<h3>Esteja Conectado</h3>
		    			<ul class="footer-stay-connected no-list-style">
		    				<li><a class="facebook"></a></li>
		    				<li><a class="twitter"></a></li>
		    				<li><a class="googleplus"></a></li>
		    			</ul>
		    		</div>
		    	</div>
		    </div>
	    </div>

        <!-- Javascripts -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="http://cdn.leafletjs.com/leaflet-0.5.1/leaflet.js"></script>
        <script src="js/jquery.fitvids.js"></script>
        <script src="js/jquery.sequence-min.js"></script>
        <script src="js/jquery.bxslider.js"></script>
        <script src="js/main-menu.js"></script>
        <script src="js/template.js"></script>

    </body>
</html>